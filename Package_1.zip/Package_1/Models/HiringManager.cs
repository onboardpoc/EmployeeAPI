﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeAPI.Models
{
    public class HiringManager
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string BId { get; set; }

        [BsonElement]
        public string ID { get; set; }

        [BsonElement]
        public string Manager_Name { get; set; }

       
    }
}
