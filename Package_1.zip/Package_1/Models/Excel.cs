﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;
using NPOI.HSSF.UserModel;
using Newtonsoft.Json;
using System.IO;
//using NPOI.XSSF.UserModel;
using NPOI.SS.Util;
using System.Security.Principal;
//using Model;
using System.Text;
//using System.DirectoryServices;
//using office = Microsoft.Office.Core;
using Word = Microsoft.Office.Interop.Word;
using System.Reflection;
//using System.Windows.Form;
//using ProcessingLayer.Utility;
using System.Diagnostics;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
//using NPOI.SS.UserModel;
//using Microsoft.AspNetCore.WebSockets.Internal;

namespace EmployeeAPI.Models
{
    public class Excel
    {
        
        public bool GenerateExcelFile(Employee emp)


        {
            try
            {
                //Stopwatch sw = new Stopwatch();
                //sw.Start();

                string sowDocumentPath = "C:\\Users\\Administrator\\Documents\\Visual Studio 2017\\SOW_Template\\SOW_Sheet.xlsx";
                string newPath = "C:\\Users\\Administrator\\Documents\\Visual Studio 2017\\New_Path\\SOW_Sheet.xlsx";
                
                //string newPath = savePath + "\\" + string.Format(Constants.GeneratedSOWDocumentNameFormat, emp.SowType.Substring(0, 2), emp.FirstName, emp.LastName, emp.Onshore, Convert.ToDateTime(emp.StartDate).ToString("dd-MM-yyyy"), Convert.ToDateTime(emp.EndDate).ToString("dd-MM-yyyy"), emp.Exhibit) + Constants.DocXLSX;
                System.IO.File.Copy(sowDocumentPath, newPath, true);

                using (FileStream rstr = new FileStream(newPath, FileMode.Open, FileAccess.Read))
                {
                    var workbook = new XSSFWorkbook(rstr);
                    var sheet = workbook.GetSheet("Details");


                    using (FileStream wstr = new FileStream(newPath, FileMode.Create, FileAccess.Write))
                    {
                        //Manager name
                        var row1 = sheet.GetRow(1);
                        var cell1 = row1.GetCell(1);
                        cell1.SetCellValue(emp.DM);//"Murtuza");

                        //Formatting
                        var row0 = sheet.GetRow(0);
                        var row1cell0 = row0.GetCell(0);
                        var row1cell1 = row0.GetCell(1);
                        var row1cell2 = row0.GetCell(2);

                        ICellStyle testStyleDisabled = workbook.CreateCellStyle();
                        testStyleDisabled.WrapText = true;
                        testStyleDisabled.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;
                        testStyleDisabled.BorderRight = NPOI.SS.UserModel.BorderStyle.Thin;
                        testStyleDisabled.BorderTop = NPOI.SS.UserModel.BorderStyle.Thin;
                        testStyleDisabled.BorderBottom = NPOI.SS.UserModel.BorderStyle.Thin;

                        testStyleDisabled.FillForegroundColor = IndexedColors.Grey25Percent.Index;
                        testStyleDisabled.FillPattern = FillPattern.SolidForeground;

                        ICellStyle testStyle = workbook.CreateCellStyle();
                        testStyle.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;
                        testStyle.BorderRight = NPOI.SS.UserModel.BorderStyle.Thin;
                        testStyle.BorderTop = NPOI.SS.UserModel.BorderStyle.Thin;
                        testStyle.BorderBottom = NPOI.SS.UserModel.BorderStyle.Thin;

                        IFont FontStyle = workbook.CreateFont();
                        FontStyle.Boldweight = (short)FontBoldWeight.Bold;
                        FontStyle.FontHeight = 12;
                        testStyle.SetFont(FontStyle);
                        testStyle.FillForegroundColor = IndexedColors.Grey25Percent.Index;
                        testStyle.FillPattern = FillPattern.SolidForeground;

                        row1cell0.CellStyle = testStyle;
                        row1cell1.CellStyle = testStyle;
                        row1cell2.CellStyle = testStyle;


                        row0 = sheet.GetRow(0);
                        var cell01 = row0.GetCell(1);
                        cell01.SetCellValue("Lables");

                        //First name
                        var row3 = sheet.GetRow(3);
                        var cell31 = row3.GetCell(1);
                        cell31.SetCellValue(emp.FirstName);//"Swapnali");


                        //Middle name
                        var row4 = sheet.GetRow(4);
                        var cell41 = row4.GetCell(1);
                        cell41.SetCellValue(emp.MiddleName);//"Ajay")


                        //Last name
                        var row5 = sheet.GetRow(5);
                        var cell51 = row5.GetCell(1);
                        cell51.SetCellValue(emp.LastName);//"Karpe"); //


                        //onshore/offshore
                        var row6 = sheet.GetRow(6);
                        var cell61 = row6.GetCell(1);
                        cell61.SetCellValue(emp.Onshore);//"Onshore");


                        //City, State
                        var row7 = sheet.GetRow(7);
                        var cell71 = row7.GetCell(1);
                        cell71.SetCellValue(emp.City + "," + emp.State);// "MH");

                        //Level
                        string level = "N/A";
                        switch (emp.ExpLevel)
                        {
                            case "L4":
                                level = "Level 4";
                                break;
                            case "L3":
                                level = "Level 3";
                                break;
                            case "L2":
                                level = "Level 2";
                                break;
                            case "L1":
                                level = "Level 1";
                                break;

                        }

                        var row9 = sheet.GetRow(9);
                        var cell91 = row9.GetCell(1);
                        cell91.SetCellValue(level);
                        var cell92 = row9.GetCell(0);
                        cell92.CellStyle = testStyleDisabled;

                        //Contractor Role
                        var row8 = sheet.GetRow(8);
                        var cell81 = row8.GetCell(1);
                        cell81.SetCellValue(emp.Role);//"Application Support"); //

                        //Premium Skill Level
                        string PSlevel = "N/A";
                        switch (emp.ExpLevel)
                        {
                            case "L4":
                                PSlevel = "Level 4";
                                break;
                            case "L3":
                                PSlevel = "Level 3";
                                break;
                            case "L2":
                                PSlevel = "Level 2";
                                break;
                            case "L1":
                                PSlevel = "Level 1";
                                break;

                        }

                        var row10 = sheet.GetRow(10);
                        var cell10_1 = row10.GetCell(1);
                        cell10_1.SetCellValue(PSlevel);

                        var cell10_2 = row10.GetCell(0);
                        cell10_2.CellStyle = testStyleDisabled;

                        //Bill Rate
                        var row13 = sheet.GetRow(13);
                        var cell13_1 = row13.GetCell(1);
                        cell13_1.SetCellValue(emp.BillRate);

                        //start date
                        var row11 = sheet.GetRow(11);
                        var cell11_1 = row11.GetCell(1);
                        cell11_1.SetCellValue(String.Format("{0:dd-MMM-yy}", emp.StartDate));//"01-Mar-19"); //

                        //End date
                        var row12 = sheet.GetRow(12);
                        var cell12_1 = row12.GetCell(1);
                        cell12_1.SetCellValue(String.Format("{0:dd-MMM-yy}", emp.EndDate));//"30-Jun-19");// 

                        //xx id
                        var row15 = sheet.GetRow(15);
                        var cell15_1 = row15.GetCell(1);
                        cell15_1.SetCellValue(emp.PNCId);//"PL09191");// 

                        //emp id
                        var row16 = sheet.GetRow(16);
                        var cell16_1 = row16.GetCell(1);
                        cell16_1.SetCellValue(emp.EmployeeId == null ? string.Empty : emp.EmployeeId.ToString());//1004473);// 

                        //Exhibit No
                        //var row20 = sheet.GetRow(19);
                        //var cell20_1 = row20.GetCell(0);
                        //string ExhibitNumber = "Exhibit#" + emp.Exhibit.ToString();
                        //cell20_1.SetCellValue(ExhibitNumber);

                        workbook.Write(wstr);
                        wstr.Close();
                    }
                    rstr.Close();
                }

                //sw.Stop();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }       
        #region Old excel code
        //public void GenerateExcelFile()
        //{

        //    DataTable dt = new DataTable();

        //    dt.Columns.Add("FirstName");
        //    dt.Columns.Add("MiddleName");
        //    dt.Columns.Add("LastName");
        //    dt.Columns.Add("DM");
        //    dt.Columns.Add("LOB");
        //    dt.Columns.Add("Onshore");
        //    dt.Columns.Add("Location");
        //    dt.Columns.Add("Role");
        //    dt.Columns.Add("ExpLevel");
        //    dt.Columns.Add("StartDate");
        //    dt.Columns.Add("EndDate");
        //    dt.Columns.Add("Notes");
        //    dt.Columns.Add("EmployeeId");
        //    dt.Columns.Add("SSN");

        //    DataRow dr = dt.NewRow();
        //    dr["FirstName"] = "Swapnali";
        //    dr["FirstName"] = "karpe";

        //    dt.Rows.Add(dr);


        //    var workbook = new HSSFWorkbook();
        //    var sheet = workbook.CreateSheet("SOWSheet");
        //    string JSON = JsonConvert.SerializeObject(dt);
        //    var items = JsonConvert.DeserializeObject<List<Employee>>(JSON);
        //    var columns = new[] { "FirstName", "MiddleName", "LastName", "DM", "LOB", "Onshore", "Location", "Role", "ExpLevel", "StartDate", "EndDate", "Notes", "EmployeeId", "SSN" };
        //    var headers = new[] { "FirstName", "MiddleName", "LastName", "DM", "LOB", "Onshore", "Location", "Role", "ExpLevel", "StartDate", "EndDate", "Notes", "EmployeeId", "SSN" };

        //    var headerRow = sheet.CreateRow(0);
        //    for (int i = 0; i < columns.Length; i++)
        //    {
        //        var cell = headerRow.CreateCell(i);
        //        cell.SetCellValue(headers[i]);
        //    }


        //    for (int i = 0; i < items.Count; i++)
        //    {
        //        var rowIndex = i + 1;
        //        var row = sheet.CreateRow(rowIndex);

        //        for (int j = 0; j < columns.Length; j++)
        //        {
        //            var cell = row.CreateCell(j);
        //            var o = items[i];
        //            cell.SetCellValue(o.GetType().GetProperty(columns[j]).GetValue(o, null).ToString());
        //        }
        //    }


        //    var stream = new MemoryStream();
        //    workbook.Write(stream);

        //    string FilePath = "D:\\Employee-Onboarding\\Sow_Excel\\SOWsheet.xls";


        //    FileStream file = new FileStream(FilePath, FileMode.CreateNew, FileAccess.Write);
        //    stream.WriteTo(file);
        //    file.Close();
        //    stream.Close();
        //}
        #endregion old excel
    }

}
