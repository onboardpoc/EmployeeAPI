﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeAPI.Models
{
    [BsonIgnoreExtraElements]
    public class Employee
    {
        [BsonId]
        [BsonIgnore]        
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        [BsonElement("Resource First Name")]
        public string FirstName { get; set; }

        [BsonElement("Resource Middle Name")]
        public string MiddleName { get; set; }

        [BsonElement("Resource Last Name")]
        public string LastName { get; set; }

        [BsonElement("DM Name")]
        public string DM { get; set; }

        [BsonElement("Hiring Manager Name")]
        public string HiringManagerName { get; set; }

        [BsonElement("Supplier Name")]
        public string SupplierName { get; set; }

        [BsonElement("Onshore/Offshore")]
        public string Onshore { get; set; }

        [BsonElement("Location")]
        public string Location { get; set; }

        [BsonElement("City")]
        public string City { get; set; }

        [BsonElement("State")]
        public string State { get; set; }

        [BsonElement("Contractor Role")]
        public string Role { get; set; }

        [BsonElement("Please specify the level of the job being requested")]
        public string Level { get; set; }

        [BsonElement("Experence Level")]
        public string ExpLevel { get; set; }

        [BsonElement("Start Date")]
        public DateTime StartDate { get; set; }

        [BsonElement("End Date")]
        public DateTime EndDate { get; set; }

        [BsonElement("PNC ID")]
        public string PNCId { get; set; }

        [BsonElement("Notes")]
        public string Notes { get; set; }

        [BsonElement("EmployeeId")]
        public int EmployeeId { get; set; }

        [BsonElement("SSN#")]
        public int SSN { get; set; }

        [BsonElement("InitiateBGC")]
        public bool InitiateBGC { get; set; }

        [BsonElement("SendSOW")]
        public bool SendSOW { get; set; }

        [BsonElement("CreatedBy")]
        public string CreatedBy { get; set; }

        [BsonElement("ModifiedBy")]
        public string ModifiedBy { get; set; }

        [BsonElement("SuplierName")]
        public string SuplierName { get; set; }

        [BsonElement("BillRate")]
        public int BillRate { get; set; }
        
        [BsonElement("ModifiedDate")]
        public DateTime ModifiedDate { get; set; }

        [BsonElement("CreatedDate")]
        public DateTime CreatedDate { get; set; }
    }
}
