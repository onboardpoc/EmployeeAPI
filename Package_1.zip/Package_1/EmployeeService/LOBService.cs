﻿using EmployeeAPI.Models;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeAPI.EmployeeService
{
    public class LOBService
    {
        private readonly IMongoCollection<LOB> _LOB;
        public LOBService(IConfiguration config)

        {
            var client = new MongoClient(config.GetConnectionString("EmployeeDb"));
            var database = client.GetDatabase("EmployeeDb");
            //_employees = database.GetCollection<Employee>("EmployeeDetails");
            _LOB = database.GetCollection<LOB>("LOB_Table");
        }

        public List<LOB> GetLOB()
        {
            //Email em = new Email();
            // em.SendEmail();

            return _LOB.Find(emp => true).ToList();
        }
        public LOB Create(LOB lob)
        {
            _LOB.InsertOne(lob);

            return lob;

        }

    }
}
