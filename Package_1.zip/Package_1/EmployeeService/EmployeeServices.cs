﻿using EmployeeAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;
using System.Data;
using Word = Microsoft.Office.Interop.Word;

namespace EmployeeAPI.EmployeeService
{
    
    public class EmployeeServices
    {
        private readonly IMongoCollection<Employee> _employees;

        public EmployeeServices(IConfiguration config)
        {
            var client = new MongoClient(config.GetConnectionString("EmployeeDb"));
            var database = client.GetDatabase("EmployeeDb");
            _employees = database.GetCollection<Employee>("TestEmployee");
            //_DM = database.GetCollection<DM>("DM_Table");
        }

        public List<Employee> Get()
        {
            return _employees.Find(emp => true).ToList();
        }



        public Employee Get(string id)
        {
            return _employees.Find<Employee>(emp => emp.Id == id).FirstOrDefault();
        }

        public  Employee Create(Employee emp)
        {
            _employees.InsertOne(emp);
          
            return emp;

        }

        public void Update(string id, Employee empl)
        {
            _employees.ReplaceOne(emp => emp.Id == id, empl);
        }

        public void Remove(Employee empl)
        {
            _employees.DeleteOne(emp => emp.Id == empl.Id);
        }

        public void Remove(string id)
        {
            _employees.DeleteOne(emp => emp.Id == id);
        }
    }
}
