﻿using EmployeeAPI.Models;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeAPI.EmployeeService
{
    public class RolesService
    {
        private readonly IMongoCollection<Roles> _Roles;
        public RolesService(IConfiguration config)

        {
            var client = new MongoClient(config.GetConnectionString("EmployeeDb"));
            var database = client.GetDatabase("EmployeeDb");
            //_employees = database.GetCollection<Employee>("EmployeeDetails");
            _Roles = database.GetCollection<Roles>("Role");
        }

        public List<Roles> GetRoles()
        {
            //Email em = new Email();
            // em.SendEmail();

            return _Roles.Find(emp => true).ToList();
        }

    }
}
