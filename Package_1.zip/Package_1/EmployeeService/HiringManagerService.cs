﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EmployeeAPI.Models;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;

namespace EmployeeAPI.EmployeeService
{
    public class HiringManagerService
    {
        private readonly IMongoCollection<HiringManager> _Manager;
        public HiringManagerService(IConfiguration config)

        {
            var client = new MongoClient(config.GetConnectionString("EmployeeDb"));
            var database = client.GetDatabase("EmployeeDb");
            //_employees = database.GetCollection<Employee>("EmployeeDetails");
            _Manager = database.GetCollection<HiringManager>("Hiring_Manager");
        }

        public List<HiringManager> GetManager()
        {
            //Email em = new Email();
            // em.SendEmail();

            return _Manager.Find(emp => true).ToList();
        }
    }
}
