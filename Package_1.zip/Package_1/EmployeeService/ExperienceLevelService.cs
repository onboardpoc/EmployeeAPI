﻿using EmployeeAPI.Models;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeAPI.EmployeeService
{
    public class ExperienceLevelService
    {
        private readonly IMongoCollection<ExperienceLevel> _exp;
        public ExperienceLevelService(IConfiguration config)

        {
            var client = new MongoClient(config.GetConnectionString("EmployeeDb"));
            var database = client.GetDatabase("EmployeeDb");
            //_employees = database.GetCollection<Employee>("EmployeeDetails");
            _exp = database.GetCollection<ExperienceLevel>("Experience_Level");
        }
        public List<ExperienceLevel> GetExperienceLevels()
        {
            //Email em = new Email();
            // em.SendEmail();

            return _exp.Find(emp => true).ToList();
        }
    }
}
