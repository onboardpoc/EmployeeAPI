﻿using EmployeeAPI.Models;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeAPI.EmployeeService
{
    public class LocationService
    {
        private readonly IMongoCollection<Locations> _Location;
        public LocationService(IConfiguration config)

        {
            var client = new MongoClient(config.GetConnectionString("EmployeeDb"));
            var database = client.GetDatabase("EmployeeDb");
            //_employees = database.GetCollection<Employee>("EmployeeDetails");
            _Location = database.GetCollection<Locations>("Location");
        }

        public List<Locations> GetLocations()
        {
            //Email em = new Email();
            // em.SendEmail();

            return _Location.Find(emp => true).ToList();
        }
    }
}
