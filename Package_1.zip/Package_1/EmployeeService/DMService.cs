﻿using EmployeeAPI.Models;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeAPI.EmployeeService
{
    public class DMService
    {
        private readonly IMongoCollection<DM> _DM;
        public DMService(IConfiguration config)

        {
            var client = new MongoClient(config.GetConnectionString("EmployeeDb"));
            var database = client.GetDatabase("EmployeeDb");
            //_employees = database.GetCollection<Employee>("EmployeeDetails");
            _DM = database.GetCollection<DM>("DM_Table");
        }

        public List<DM> GetDM()
        {
            //Email em = new Email();
            // em.SendEmail();

            return _DM.Find(emp => true).ToList();
        }

        public DM Create(DM dm)
        {
            _DM.InsertOne(dm);

            return dm;

        }
    }
}
