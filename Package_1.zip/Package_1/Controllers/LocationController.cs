﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EmployeeAPI.EmployeeService;
using EmployeeAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace EmployeeAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LocationController : ControllerBase
    {
        private readonly LocationService _LocationService;
        public LocationController(LocationService LocationService)
        {
            _LocationService = LocationService;
        }
        [HttpGet]
        public ActionResult<List<Locations>> Get()
        {
            return _LocationService.GetLocations();
        }
    }
}