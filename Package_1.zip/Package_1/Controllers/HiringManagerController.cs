﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EmployeeAPI.EmployeeService;
using EmployeeAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace EmployeeAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HiringManagerController : ControllerBase
    {
        private readonly HiringManagerService _HiringManagerService;
        public HiringManagerController(HiringManagerService HiringManagerService)
        {
            _HiringManagerService = HiringManagerService;
        }
        [HttpGet]
        public ActionResult<List<HiringManager>> Get()
        {
            return _HiringManagerService.GetManager();
        }
    }
}