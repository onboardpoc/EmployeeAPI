﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EmployeeAPI.EmployeeService;
using EmployeeAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;

namespace EmployeeAPI.Controllers
{
    [EnableCors("_myAllowSpecificOrigins")]
    [Route("api/[controller]")]
    [ApiController]
    public class LOBController : ControllerBase
    {
            private readonly LOBService _LOBService;
            public LOBController(LOBService LOBService)
            {
            _LOBService = LOBService;
            }
            [HttpGet]
            public ActionResult<List<LOB>> Get()
            {
                return _LOBService.GetLOB();
            }
        [HttpPost]
        public ActionResult<Employee> Create(LOB Lob)
        {
            _LOBService.Create(Lob);
            return CreatedAtRoute("GetEmployee", new { id = Lob.ID.ToString() }, Lob);
        }

        
    }
    
}