﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EmployeeAPI.EmployeeService;
using EmployeeAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace EmployeeAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RolesController : ControllerBase
    {
        private readonly RolesService _RolesService;
        public RolesController(RolesService RolesService)
        {
            _RolesService = RolesService;
        }
        [HttpGet]
        public ActionResult<List<Roles>> Get()
        {
            return _RolesService.GetRoles();
        }

    }
}