﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EmployeeAPI.EmployeeService;
using EmployeeAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;

namespace EmployeeAPI.Controllers
{
    [EnableCors("_myAllowSpecificOrigins")]
    [Route("api/[controller]")]
    [ApiController]
    public class DMController : ControllerBase
    {
        private readonly DMService _DMService;
        public DMController(DMService DMService)
        {
            _DMService = DMService;
        }
        [HttpGet]
        public ActionResult<List<DM>> Get()
        {
            return _DMService.GetDM();
        }

        [HttpPost]
        public ActionResult<Employee> Create(DM dm)
        {
            _DMService.Create(dm);
            return CreatedAtRoute("GetEmployee", new { id = dm.ID.ToString() },dm);
        }
    }
}