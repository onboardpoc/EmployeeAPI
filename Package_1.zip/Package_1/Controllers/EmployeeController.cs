﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using EmployeeAPI.EmployeeService;
using EmployeeAPI.Models;

using Microsoft.AspNetCore.Cors;



namespace EmployeeAPI.Controllers
{
    [EnableCors("_myAllowSpecificOrigins")]
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly EmployeeService.EmployeeServices _employeeService;
        
        public EmployeeController(EmployeeServices EmployeeService)
        {
            _employeeService = EmployeeService;
           
        }

        [HttpGet]
        public ActionResult<List<Employee>> Get()
        {
            var data= _employeeService.Get();
            Excel ex = new Excel();
            ex.GenerateExcelFile(data.FirstOrDefault());
            Email em = new Email();
            em.SendEmail();
            return data;
        }

      
        [HttpGet("{id:length(24)}", Name = "GetEmployee")]
        public ActionResult<Employee> Get(string id)
        {
            var Employee = _employeeService.Get(id);

            if (Employee == null)
            {
                return NotFound();
            }

            return Employee;
        }

        [HttpPost]
        public ActionResult<Employee> Create(Employee Employee)
        {
            _employeeService.Create(Employee);
            return CreatedAtRoute("GetEmployee", new { id = Employee.Id.ToString() }, Employee);
        }

        [HttpPut("{id:length(24)}")]
        public IActionResult Update(string id, Employee EmployeeIn)
        {
            var Employee = _employeeService.Get(id);

            if (Employee == null)
            {
                return NotFound();
            }

            _employeeService.Update(id, EmployeeIn);

            return NoContent();
        }

        [HttpDelete("{id:length(24)}")]
        public IActionResult Delete(string id)
        {
            var Employee = _employeeService.Get(id);

            if (Employee == null)
            {
                return NotFound();
            }

            _employeeService.Remove(Employee.Id);

            return NoContent();
        }
    }
   }