﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EmployeeAPI.EmployeeService;
using EmployeeAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace EmployeeAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ExperienceLevelController : ControllerBase
    {
        private readonly ExperienceLevelService _ExperienceLevelService;
        public ExperienceLevelController(ExperienceLevelService ExperienceLevelService)
        {
            _ExperienceLevelService = ExperienceLevelService;
        }
        [HttpGet]
        public ActionResult<List<ExperienceLevel>> Get()
        {
            return _ExperienceLevelService.GetExperienceLevels();
        }
    }
}